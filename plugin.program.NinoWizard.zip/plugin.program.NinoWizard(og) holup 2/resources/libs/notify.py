################################################################################
#      Copyright (C) 2015 Surfacingx                                           #
#                                                                              #
#  This Program is free software; you can redistribute it and/or modify        #
#  it under the terms of the GNU General Public License as published by        #
#  the Free Software Foundation; either version 2, or (at your option)         #
#  any later version.                                                          #
#                                                                              #
#  This Program is distributed in the hope that it will be useful,             #
#  but WITHOUT ANY WARRANTY; without even the implied warranty of              #
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the                #
#  GNU General Public License for more details.                                #
#                                                                              #
#  You should have received a copy of the GNU General Public License           #
#  along with XBMC; see the file COPYING.  If not, write to                    #
#  the Free Software Foundation, 675 Mass Ave, Cambridge, MA 02139, USA.       #
#  http://www.gnu.org/copyleft/gpl.html                                        #
################################################################################

import os
import xbmc, xbmcgui, xbmcvfs
import re
import uservar
from resources.libs import wizard as wiz
from datetime import date, timedelta
from urllib.parse import quote_plus

transPath  = xbmcvfs.translatePath
LOGNOTICE = xbmc.LOGINFO

ART            = os.path.join(ADDONPATH,   'resources', 'art')
SKINFOLD       = os.path.join(ADDONPATH,   'resources', 'skins', 'DefaultSkin', 'media')
ADVANCED       = os.path.join(USERDATA,  'advancedsettings.xml')
NOTIFY         = wiz.getS('notify')

if BACKGROUND == '': BACKGROUND = FANART
elif not wiz.workingURL(BACKGROUND): BACKGROUND = FANART

ACTION_PREVIOUS_MENU            =  10   ## ESC action
ACTION_NAV_BACK                 =  92   ## Backspace action
ACTION_MOVE_LEFT                =   1   ## Left arrow key
ACTION_MOVE_RIGHT               =   2   ## Right arrow key
ACTION_MOVE_UP                  =   3   ## Up arrow key
ACTION_MOVE_DOWN                =   4   ## Down arrow key
ACTION_MOUSE_WHEEL_UP           = 104   ## Mouse wheel up
ACTION_MOUSE_WHEEL_DOWN         = 105   ## Mouse wheel down
ACTION_MOVE_MOUSE               = 107   ## Down arrow key
ACTION_SELECT_ITEM              =   7   ## Number Pad Enter
ACTION_BACKSPACE                = 110   ## ?
ACTION_MOUSE_LEFT_CLICK         = 100
ACTION_MOUSE_LONG_CLICK         = 108

def artwork(file):
    if   file == 'button': return os.path.join(SKINFOLD, 'Button', 'button-focus_lightblue.png'), os.path.join(SKINFOLD, 'Button', 'button-focus_grey.png')
    elif file == 'radio' : return os.path.join(SKINFOLD, 'RadioButton', 'MenuItemFO.png'), os.path.join(SKINFOLD, 'RadioButton', 'MenuItemNF.png'), os.path.join(SKINFOLD, 'RadioButton', 'radiobutton-focus.png'), os.path.join(SKINFOLD, 'RadioButton', 'radiobutton-nofocus.png')
    elif file == 'slider': return os.path.join(SKINFOLD, 'Slider', 'osd_slider_nib.png'), os.path.join(SKINFOLD, 'Slider', 'osd_slider_nibNF.png'), os.path.join(SKINFOLD, 'Slider', 'slider1.png'), os.path.join(SKINFOLD, 'Slider', 'slider1.png')

def autoConfig(msg='', TxtColor='0xFFFFFFFF', Font='font12', BorderWidth=10):
    class MyWindow(xbmcgui.WindowDialog):
        scr={};
        def __init__(self,msg='',L=0,T=0,W=1280,H=720,TxtColor='0xFFFFFFFF',Font='font12',BorderWidth=10):
            if os.path.exists(ADVANCED):
                r = xbmcvfs.File(ADVANCED).read()
                if KODIV < 17:
                    try:
                        asvideocachevalue = re.findall('<cachemembuffersize>(.+?)</cachemembuffersize>', r, re.DOTALL)[0]
                    except:
                        asvideocachevalue = '20971520'
                    try:
                        asreadfactor = re.findall('<readbufferfactor>(.+?)</readbufferfactor>', r, re.DOTALL)[0]
                    except:
                        asreadfactor = '4.0'
                else:
                    try:
                        asvideocachevalue = re.findall('<memorysize>(.+?)</memorysize>', r, re.DOTALL)[0]
                    except:
                        asvideocachevalue = '20971520'
                    try:
                        asreadfactor = re.findall('<readfactor>(.+?)</readfactor>', r, re.DOTALL)[0]
                    except:
                        asreadfactor = '4.0'
                asvideocachevalue = int(int(asvideocachevalue)/(1024*1024))
                try:
                    ascurl = re.findall('<curlclienttimeout>(.+?)</curlclienttimeout>', r, re.DOTALL)[0]
                except:
                    ascurl = '10'
                try:
                    asbuffer = re.findall('<buffermode>(.+?)</buffermode>', r, re.DOTALL)[0]
                except:
                    asbuffer = '0'
                asvideocachevalue = ' = [B][COLOR lime]%s[/COLOR][/B] MB' % asvideocachevalue
                ascurl = ' = [B][COLOR lime]%s[/COLOR][/B]' % ascurl
                asreadfactor = ' = [B][COLOR lime]%s[/COLOR][/B]' % asreadfactor
                asbuffer = ' = [B][COLOR lime]%s[/COLOR][/B]' % asbuffer
            else:
                asvideocachevalue = ' : [COLOR yellow]20[/COLOR] MB'
                ascurl = ' : [COLOR yellow]10[/COLOR]'
                asreadfactor = ' : [COLOR yellow]4.0[/COLOR]'
                asbuffer = ' : [COLOR yellow]0[/COLOR]'
            buttonfocus, buttonnofocus = artwork('button')
            radiobgfocus, radiobgnofocus, radiofocus, radionofocus = artwork('radio')
            slidernibfocus, slidernibnofocus, sliderfocus, slidernofocus = artwork('slider')
            image_path = os.path.join(ART, 'ContentPanel.png')
            boxbg = os.path.join(ART, 'bgg2.png')
            self.border = xbmcgui.ControlImage(L,T,W,H, image_path)
            self.addControl(self.border);
            self.BG=xbmcgui.ControlImage(L+BorderWidth,T+BorderWidth,W-(BorderWidth*2),H-(BorderWidth*2), FANART, aspectRatio=0, colorDiffuse='0x5FFFFFFF')
            self.addControl(self.BG)
            top = T+BorderWidth
            leftside = L+BorderWidth
            rightside = L+int(W/2)-(BorderWidth*2)
            firstrow = top+30
            secondrow = firstrow+275+int(BorderWidth/2)
            currentwidth = int(((W/2)-(BorderWidth*4))/2)

            header = '[COLOR %s]Advanced Settings Configurator[/COLOR]' % (COLOR2)
            self.Header=xbmcgui.ControlLabel(L, top, W, 30, header, font='font13', textColor=TxtColor, alignment=0x00000002)
            self.addControl(self.Header)
            top += 30+BorderWidth
            self.bgarea = xbmcgui.ControlImage(leftside, firstrow, rightside-L, 275, boxbg, aspectRatio=0, colorDiffuse='0x5FFFFFFF')
            self.addControl(self.bgarea)
            self.bgarea2 = xbmcgui.ControlImage(rightside+BorderWidth+BorderWidth, firstrow, rightside-L, 275, boxbg, aspectRatio=0, colorDiffuse='0x5FFFFFFF')
            self.addControl(self.bgarea2)
            self.bgarea3 = xbmcgui.ControlImage(leftside, secondrow, rightside-L, 275, boxbg, aspectRatio=0, colorDiffuse='0x5FFFFFFF')
            self.addControl(self.bgarea3)
            self.bgarea4 = xbmcgui.ControlImage(rightside+BorderWidth+BorderWidth, secondrow, rightside-L, 275, boxbg, aspectRatio=0, colorDiffuse='0x5FFFFFFF')
            self.addControl(self.bgarea4)

            header = '[COLOR %s]Video Cache Size[/COLOR]%s' % (COLOR2, asvideocachevalue)
            self.Header2=xbmcgui.ControlLabel(leftside+BorderWidth, firstrow+5, int(W/2)-(BorderWidth*2), 20, header, font='font13', textColor=TxtColor, alignment=0x00000002)
            self.addControl(self.Header2)
            freeMemory = int(float(wiz.getInfo('System.Memory(free)')[:-2])*.33)
            recMemory = int(float(wiz.getInfo('System.Memory(free)')[:-2])*.23)
            msg3 = "[COLOR %s]Number of bytes used for buffering streams in memory.  When set to [COLOR %s]0[/COLOR] the cache will be written to disk instead of RAM.  Note: For the memory size set here, Kodi will require 3x the amount of RAM to be free. Setting this too high might cause Kodi to crash if it can't get enough RAM(1/3 of Free Memory: [COLOR %s]%s[/COLOR])[/COLOR]" % (COLOR2, COLOR1, COLOR1, freeMemory)
            self.Support3=xbmcgui.ControlTextBox(leftside+int(BorderWidth*1.5), firstrow+30+BorderWidth, int(W/2)-(BorderWidth*4), 150, font='font12', textColor=TxtColor)
            self.addControl(self.Support3)
            self.Support3.setText(msg3)
            try: self.videoCacheSize=xbmcgui.ControlSlider(leftside+int(BorderWidth*1.5), firstrow+210,int(W/2)-(BorderWidth*5),20, textureback=sliderfocus, texture=slidernibnofocus, texturefocus=slidernibfocus, orientation=xbmcgui.HORIZONTAL)
            except: self.videoCacheSize=xbmcgui.ControlSlider(leftside+int(BorderWidth*1.5), firstrow+210,int(W/2)-(BorderWidth*5),20, textureback=sliderfocus, texture=slidernibnofocus, texturefocus=slidernibfocus)
            self.addControl(self.videoCacheSize)
            self.videomin = 0; self.videomax = freeMemory if freeMemory < 2000 else 2000
            self.recommendedVideo = recMemory if recMemory < 500 else 500; self.currentVideo = self.recommendedVideo
            videopos = wiz.percentage(self.currentVideo, self.videomax)
            self.videoCacheSize.setPercent(int(videopos))
            current1 = '[COLOR %s]New size:[/COLOR] [COLOR %s]%s MB[/COLOR]' % (COLOR1, COLOR2, self.currentVideo)
            recommended1 = '[COLOR %s]Recommended:[/COLOR] [COLOR %s]%s MB[/COLOR]' % (COLOR1, COLOR2, self.recommendedVideo)
            self.currentVideo1=xbmcgui.ControlTextBox(leftside+BorderWidth,firstrow+235,currentwidth,20,font=Font,textColor=TxtColor)
            self.addControl(self.currentVideo1)
            self.currentVideo1.setText(current1)
            self.recommendedVideo1=xbmcgui.ControlTextBox(leftside+BorderWidth+currentwidth,firstrow+235,currentwidth,20,font=Font,textColor=TxtColor)
            self.addControl(self.recommendedVideo1)
            self.recommendedVideo1.setText(recommended1)

            header = '[COLOR %s]CURL Timeout/CURL Low Speed[/COLOR]%s' % (COLOR2, ascurl)
            self.Header3=xbmcgui.ControlLabel(rightside+BorderWidth, firstrow+5, int(W/2)-(BorderWidth*2), 20, header, font='font13', textColor=TxtColor, alignment=0x00000002)
            self.addControl(self.Header3)
            msg3 = "[COLOR %s][B]curlclienttimeout[/B] is the time in seconds for how long it takes for libcurl connection will timeout and [B]curllowspeedtime[/B] is the time in seconds for libcurl to consider a connection lowspeed.  For slower connections set it to 20.[/COLOR]" % COLOR2
            self.Support3=xbmcgui.ControlTextBox(rightside+int(BorderWidth*3.5), firstrow+30+BorderWidth, int(W/2)-(BorderWidth*4), 150, font='font12', textColor=TxtColor)
            self.addControl(self.Support3)
            self.Support3.setText(msg3)
            try: self.CURLTimeout=xbmcgui.ControlSlider(rightside+int(BorderWidth*3.5),firstrow+210,int(W/2)-(BorderWidth*5),20, textureback=sliderfocus, texture=slidernibnofocus, texturefocus=slidernibfocus, orientation=xbmcgui.HORIZONTAL)
            except: self.CURLTimeout=xbmcgui.ControlSlider(rightside+int(BorderWidth*3.5),firstrow+210,int(W/2)-(BorderWidth*5),20, textureback=sliderfocus, texture=slidernibnofocus, texturefocus=slidernibfocus)
            self.addControl(self.CURLTimeout)
            self.curlmin = 0; self.curlmax = 20
            self.recommendedCurl = 10; self.currentCurl = self.recommendedCurl
            curlpos = wiz.percentage(self.currentCurl, self.curlmax)
            self.CURLTimeout.setPercent(curlpos)
            current2 = '[COLOR %s]New time:[/COLOR] [COLOR %s]%ss[/COLOR]' % (COLOR1, COLOR2, self.currentCurl)
            recommended2 = '[COLOR %s]Recommended:[/COLOR] [COLOR %s]%ss[/COLOR]' % (COLOR1, COLOR2, self.recommendedCurl)
            self.currentCurl2=xbmcgui.ControlTextBox(rightside+(BorderWidth*3),firstrow+235,currentwidth,20,font=Font,textColor=TxtColor)
            self.addControl(self.currentCurl2)
            self.currentCurl2.setText(current2)
            self.recommendedCurl2=xbmcgui.ControlTextBox(rightside+(BorderWidth*3)+currentwidth,firstrow+235,currentwidth,20,font=Font,textColor=TxtColor)
            self.addControl(self.recommendedCurl2)
            self.recommendedCurl2.setText(recommended2)

            header = '[COLOR %s]Read Buffer Factor[/COLOR]%s' % (COLOR2, asreadfactor)
            self.Header4=xbmcgui.ControlLabel(leftside, secondrow+5, int(W/2)-(BorderWidth*2), 20, header, font='font13', textColor=TxtColor, alignment=0x00000002)
            self.addControl(self.Header4)
            msg3 = "[COLOR %s]The value of this setting is a multiplier of the default limit. If Kodi is loading a typical bluray raw file at 36 Mbit/s, then a value of 2 will need at least 72 Mbit/s of network bandwidth. However, unlike with the RAM setting, you can safely increase this value however high you want, and Kodi won't crash.[/COLOR]" % COLOR2
            self.Support3=xbmcgui.ControlTextBox(leftside+int(BorderWidth*1.5), secondrow+30+BorderWidth, int(W/2)-(BorderWidth*4), 150, font='font12', textColor=TxtColor)
            self.addControl(self.Support3)
            self.Support3.setText(msg3)
            try: self.readBufferFactor=xbmcgui.ControlSlider(leftside+int(BorderWidth*1.5), secondrow+210,int(W/2)-(BorderWidth*5),20, textureback=sliderfocus, texture=slidernibnofocus, texturefocus=slidernibfocus, orientation=xbmcgui.HORIZONTAL)
            except: self.readBufferFactor=xbmcgui.ControlSlider(leftside+int(BorderWidth*1.5), secondrow+210,int(W/2)-(BorderWidth*5),20, textureback=sliderfocus, texture=slidernibnofocus, texturefocus=slidernibfocus)
            self.addControl(self.readBufferFactor)
            self.readmin = 0; self.readmax = 10
            self.recommendedRead = 5; self.currentRead = self.recommendedRead
            readpos = wiz.percentage(self.currentRead, self.readmax)
            self.readBufferFactor.setPercent(readpos)
            current3 = '[COLOR %s]New value:[/COLOR] [COLOR %s]%s[/COLOR]' % (COLOR1, COLOR2, self.currentRead)
            recommended3 = '[COLOR %s]Recommended:[/COLOR] [COLOR %s]%s[/COLOR]' % (COLOR1, COLOR2, self.recommendedRead)
            self.currentRead3=xbmcgui.ControlTextBox(leftside+BorderWidth,secondrow+235,currentwidth,20,font=Font,textColor=TxtColor)
            self.addControl(self.currentRead3)
            self.currentRead3.setText(current3)
            self.recommendedRead3=xbmcgui.ControlTextBox(leftside+BorderWidth+currentwidth,secondrow+235,currentwidth,20,font=Font,textColor=TxtColor)
            self.addControl(self.recommendedRead3)
            self.recommendedRead3.setText(recommended3)

            header = '[COLOR %s]Buffer Mode[/COLOR]%s' % (COLOR2, asbuffer)
            self.Header4=xbmcgui.ControlLabel(rightside+BorderWidth, secondrow+5, int(W/2)-(BorderWidth*2), 20, header, font='font13', textColor=TxtColor, alignment=0x00000002)
            self.addControl(self.Header4)
            msg4 = "[COLOR %s]This setting will force Kodi to use a cache for all video files, including local network, internet, and even the local hard drive. Default value is 0 and will only cache videos that use internet file paths/sources.[/COLOR]" % COLOR2
            self.Support4=xbmcgui.ControlTextBox(rightside+int(BorderWidth*3.5), secondrow+30+BorderWidth, int(W/2)-(BorderWidth*4), 110, font='font12', textColor=TxtColor)
            self.addControl(self.Support4)
            self.Support4.setText(msg4)
            B1 = secondrow+130+BorderWidth; B2 = B1+30; B3 = B2+30; B4 = B3+30;
            self.Button0 = xbmcgui.ControlRadioButton(rightside+(BorderWidth*3), B1, int(W/2)-(BorderWidth*4), 30, '0: Buffer all internet filesystems', font='font12', focusTexture=radiobgfocus, noFocusTexture=radiobgnofocus, focusOnTexture=radiofocus, noFocusOnTexture=radiofocus, focusOffTexture=radionofocus, noFocusOffTexture=radionofocus)
            self.Button1 = xbmcgui.ControlRadioButton(rightside+(BorderWidth*3), B2, int(W/2)-(BorderWidth*4), 30, '1: Buffer all filesystems', font='font12', focusTexture=radiobgfocus, noFocusTexture=radiobgnofocus, focusOnTexture=radiofocus, noFocusOnTexture=radiofocus, focusOffTexture=radionofocus, noFocusOffTexture=radionofocus)
            self.Button2 = xbmcgui.ControlRadioButton(rightside+(BorderWidth*3), B3, int(W/2)-(BorderWidth*4), 30, '2: Only buffer true internet filesystems', font='font12', focusTexture=radiobgfocus, noFocusTexture=radiobgnofocus, focusOnTexture=radiofocus, noFocusOnTexture=radiofocus, focusOffTexture=radionofocus, noFocusOffTexture=radionofocus)
            self.Button3 = xbmcgui.ControlRadioButton(rightside+(BorderWidth*3), B4, int(W/2)-(BorderWidth*4), 30, '3: No Buffer', font='font12', focusTexture=radiobgfocus, noFocusTexture=radiobgnofocus, focusOnTexture=radiofocus, noFocusOnTexture=radiofocus, focusOffTexture=radionofocus, noFocusOffTexture=radionofocus)
            self.addControl(self.Button0)
            self.addControl(self.Button1)
            self.addControl(self.Button2)
            self.addControl(self.Button3)
            self.Button0.setSelected(False)
            self.Button1.setSelected(False)
            self.Button2.setSelected(True)
            self.Button3.setSelected(False)

            self.buttonWrite=xbmcgui.ControlButton(leftside,T+H-40-BorderWidth,int(W/2)-(BorderWidth*2),35,"Write File",textColor="0xFF000000",focusedColor="0xFF000000",alignment=2,focusTexture=buttonfocus,noFocusTexture=buttonnofocus)
            self.buttonCancel=xbmcgui.ControlButton(rightside+BorderWidth*2,T+H-40-BorderWidth,int(W/2)-(BorderWidth*2),35,"Cancel",textColor="0xFF000000",focusedColor="0xFF000000",alignment=2,focusTexture=buttonfocus,noFocusTexture=buttonnofocus)
            self.addControl(self.buttonWrite); self.addControl(self.buttonCancel)

            self.buttonWrite.controlLeft(self.buttonCancel); self.buttonWrite.controlRight(self.buttonCancel); self.buttonWrite.controlUp(self.Button3); self.buttonWrite.controlDown(self.videoCacheSize)
            self.buttonCancel.controlLeft(self.buttonWrite); self.buttonCancel.controlRight(self.buttonWrite); self.buttonCancel.controlUp(self.Button3); self.buttonCancel.controlDown(self.videoCacheSize)
            self.videoCacheSize.controlUp(self.buttonWrite); self.videoCacheSize.controlDown(self.CURLTimeout)
            self.CURLTimeout.controlUp(self.videoCacheSize); self.CURLTimeout.controlDown(self.readBufferFactor)
            self.readBufferFactor.controlUp(self.CURLTimeout); self.readBufferFactor.controlDown(self.Button0)
            self.Button0.controlUp(self.CURLTimeout); self.Button0.controlDown(self.Button1); self.Button0.controlLeft(self.readBufferFactor); self.Button0.controlRight(self.readBufferFactor);
            self.Button1.controlUp(self.Button0); self.Button1.controlDown(self.Button2); self.Button1.controlLeft(self.readBufferFactor); self.Button1.controlRight(self.readBufferFactor);
            self.Button2.controlUp(self.Button1); self.Button2.controlDown(self.Button3); self.Button2.controlLeft(self.readBufferFactor); self.Button2.controlRight(self.readBufferFactor);
            self.Button3.controlUp(self.Button2); self.Button3.controlDown(self.buttonWrite); self.Button3.controlLeft(self.readBufferFactor); self.Button3.controlRight(self.readBufferFactor);
            self.setFocus(self.videoCacheSize)

        def doExit(self):
            self.CloseWindow()

        def updateCurrent(self, control):
            if control == self.videoCacheSize:
                self.currentVideo = int((self.videomax)*self.videoCacheSize.getPercent()/100)
                current = '[COLOR %s]New size:[/COLOR] [COLOR %s]%s MB[/COLOR]' % (COLOR1, COLOR2, self.currentVideo)
                self.currentVideo1.setText(current)
            elif control == self.CURLTimeout:
                self.currentCurl = int((self.curlmax)*self.CURLTimeout.getPercent()/100)
                current = '[COLOR %s]New time:[/COLOR] [COLOR %s]%ss[/COLOR]' % (COLOR1, COLOR2, self.currentCurl)
                self.currentCurl2.setText(current)
            elif control == self.readBufferFactor:
                self.currentRead = int((self.readmax)*self.readBufferFactor.getPercent()/100)
                current = '[COLOR %s]New value:[/COLOR] [COLOR %s]%s[/COLOR]' % (COLOR1, COLOR2, self.currentRead)
                self.currentRead3.setText(current)
            elif control in [self.Button0, self.Button1, self.Button2, self.Button3]:
                self.Button0.setSelected(False)
                self.Button1.setSelected(False)
                self.Button2.setSelected(False)
                self.Button3.setSelected(False)
                control.setSelected(True)

        def doWrite(self):
            #self.currentVideo = int((self.videomax-20)*self.videoCacheSize.getPercent()/100+20)*1024*1024
            #self.currentCurl = int((self.curlmax)*self.CURLTimeout.getPercent()/100)
            #self.currentRead = int((self.readmax)*self.readBufferFactor.getPercent()/100)
            if   self.Button0.isSelected(): buffermode = 0
            elif self.Button1.isSelected(): buffermode = 1
            elif self.Button2.isSelected(): buffermode = 2
            elif self.Button3.isSelected(): buffermode = 3
            if os.path.exists(ADVANCED):
                choice = DIALOG.yesno(ADDONTITLE, "[COLOR %s]There is currently an active [COLOR %s]AdvancedSettings.xml[/COLOR], would you like to remove it and continue?[/COLOR]" % (COLOR2, COLOR1), yeslabel="[B][COLOR springgreen]Remove Settings[/COLOR][/B]", nolabel="[B][COLOR red]Cancel Write[/COLOR][/B]")
                if choice == 0: return
                try: xbmcvfs.delete(ADVANCED)
                except: f = xbmcvfs.File(ADVANCED, 'w'); f.close()
            if KODIV < 17:
                with xbmcvfs.File(ADVANCED, 'w') as f:
                    f.write('<advancedsettings>\n')
                    f.write('   <network>\n')
                    f.write('       <buffermode>%s</buffermode>\n' % buffermode)
                    f.write('       <cachemembuffersize>%s</cachemembuffersize>\n' % int(self.currentVideo*1024*1024))
                    f.write('       <readbufferfactor>%s</readbufferfactor>\n' % self.currentRead)
                    f.write('       <curlclienttimeout>%s</curlclienttimeout>\n' % self.currentCurl)
                    f.write('       <curllowspeedtime>%s</curllowspeedtime>\n' % self.currentCurl)
                    f.write('   </network>\n')
                    f.write('</advancedsettings>\n')
                f.close()
            else:
                with xbmcvfs.File(ADVANCED, 'w') as f:
                    f.write('<advancedsettings>\n')
                    f.write('   <cache>\n')
                    f.write('       <buffermode>%s</buffermode>\n' % buffermode)
                    f.write('       <memorysize>%s</memorysize>\n' % int(self.currentVideo*1024*1024))
                    f.write('       <readfactor>%s</readfactor>\n' % self.currentRead)
                    f.write('   </cache>\n')
                    f.write('   <network>\n')
                    f.write('       <curlclienttimeout>%s</curlclienttimeout>\n' % self.currentCurl)
                    f.write('       <curllowspeedtime>%s</curllowspeedtime>\n' % self.currentCurl)
                    f.write('   </network>\n')
                    f.write('</advancedsettings>\n')
                f.close()
            self.CloseWindow()

        def onControl(self, control):
            try:
                cntrl=control.getId()
            except:
                cntrl=False
            if   cntrl==self.buttonWrite.getId(): self.doWrite()
            elif cntrl==self.buttonCancel.getId():  self.doExit()

        def onAction(self, action):
            try:
                F=self.getFocusId()
            except:
                F=False
            if   F == self.videoCacheSize.getId(): self.updateCurrent(self.videoCacheSize)
            elif F == self.CURLTimeout.getId(): self.updateCurrent(self.CURLTimeout)
            elif F == self.readBufferFactor.getId(): self.updateCurrent(self.readBufferFactor)
            elif F == self.Button0.getId() and action in [ACTION_MOUSE_LEFT_CLICK, ACTION_SELECT_ITEM]: self.updateCurrent(self.Button0)
            elif F == self.Button1.getId() and action in [ACTION_MOUSE_LEFT_CLICK, ACTION_SELECT_ITEM]: self.updateCurrent(self.Button1)
            elif F == self.Button2.getId() and action in [ACTION_MOUSE_LEFT_CLICK, ACTION_SELECT_ITEM]: self.updateCurrent(self.Button2)
            elif F == self.Button3.getId() and action in [ACTION_MOUSE_LEFT_CLICK, ACTION_SELECT_ITEM]: self.updateCurrent(self.Button3)
            elif action == ACTION_PREVIOUS_MENU: self.doExit()
            elif action == ACTION_NAV_BACK: self.doExit()
        def CloseWindow(self): self.close()

    maxW=1280; maxH=720; W=int(900); H=int(650); L=int((maxW-W)/2); T=int((maxH-H)/2);
    TempWindow=MyWindow(L=L,T=T,W=W,H=H,TxtColor=TxtColor,Font=Font,BorderWidth=BorderWidth);
    TempWindow.doModal()
    del TempWindow